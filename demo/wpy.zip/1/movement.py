import random
from constants import GRID_WIDTH, GRID_HEIGHT, BUSH_ROW

def step_towards(current_pos, target_pos, weight=1):
    dx = target_pos[0] - current_pos[0]
    dy = target_pos[1] - current_pos[1]
    
    move_x = 0
    move_y = 0
    
    if dx != 0:
        move_x = weight if dx > 0 else -weight
    if dy != 0:
        move_y = weight if dy > 0 else -weight
        
    return (
        max(0, min(GRID_WIDTH-1, current_pos[0] + move_x)),
        max(0, min(GRID_HEIGHT-1, current_pos[1] + move_y))
    )

def roam_step(current_pos, target_row=BUSH_ROW):
    # First step random
    random_x = current_pos[0] + random.choice([-1, 0, 1])
    random_y = current_pos[1] + random.choice([-1, 0, 1])
    random_pos = (
        max(0, min(GRID_WIDTH-1, random_x)),
        max(0, min(GRID_HEIGHT-1, random_y))
    )
    
    # Second step towards target row
    dy = target_row - current_pos[1]
    vertical_move = 1 if dy > 0 else -1 if dy < 0 else 0
    
    return random_pos, (
        random_pos[0],
        max(0, min(GRID_HEIGHT-1, random_pos[1] + vertical_move))
    )