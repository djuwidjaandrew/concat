import random
from constants import GRID_WIDTH, GRID_HEIGHT

def get_valid_moves(current_pos):
    x, y = current_pos
    possible_moves = [
        (x+1, y), (x-1, y),
        (x, y+1), (x, y-1)
    ]
    return [(x, y) for x, y in possible_moves 
            if 0 <= x < GRID_WIDTH and 0 <= y < GRID_HEIGHT]

def step_towards_target(current_pos, target_pos):
    cx, cy = current_pos
    tx, ty = target_pos
    
    # Get direction towards target
    dx = 0 if cx == tx else (tx - cx) // abs(tx - cx)
    dy = 0 if cy == ty else (ty - cy) // abs(ty - cy)
    
    # Choose either horizontal or vertical movement
    if dx != 0 and dy != 0:
        if random.random() < 0.5:
            return (cx + dx, cy)
        else:
            return (cx, cy + dy)
    return (cx + dx, cy + dy)

def random_walk(current_pos):
    valid_moves = get_valid_moves(current_pos)
    return random.choice(valid_moves)

def cat_movement(current_pos, target_pos):
    # 50-50 chance between random walk and target movement
    if random.random() < 0.5:
        return random_walk(current_pos)
    else:
        return step_towards_target(current_pos, target_pos)