import pygame
import random
import time
from cat import Cat
from rat import Rat
from text_display import TextDisplay
from constants import (
    Bush, 
    COLORS, 
    GRID_SIZE, 
    WINDOW_WIDTH, 
    WINDOW_HEIGHT, 
    BUSH_SIZE,
    GRID_HEIGHT,
    LEARNING_RATE
)

class World:
    def __init__(self):
        pygame.init()
        self.width = WINDOW_WIDTH
        self.height = WINDOW_HEIGHT
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Cat and Rat Simulation")
        
        # Offset for centering (5% of screen)
        x_offset = int(WINDOW_WIDTH * 0.05)
        y_offset = int(WINDOW_HEIGHT * 0.05)
        
        # Game state - bushes spread wider and moved down/right
        self.bush_positions = {
            Bush.BUSH1: (x_offset + 20, y_offset + 20),      # Left side
            Bush.BUSH2: (x_offset + 40, y_offset + 20),      # Left-middle
            Bush.BUSH3: (x_offset + 60, y_offset + 20),      # Middle
            Bush.BUSH4: (x_offset + 80, y_offset + 20),      # Right-middle
            Bush.BUSH5: (x_offset + 100, y_offset + 20),     # Right side
        }
        
        # Initialize catches for all bushes
        self.bush_catches = {bush: 0 for bush in Bush}
        
        # Initialize entities
        self.cat = Cat(x_offset + 50, GRID_HEIGHT - 20)  # Start at bottom center
        self.rat = Rat(self.bush_positions)
        self.text_display = TextDisplay(self.screen)
        
        self.reset_simulation()

    def reset_simulation(self):
        # Reset cat's position and state (but don't create new instance)
        x_offset = int(WINDOW_WIDTH * 0.05)
        self.cat.reset(self.bush_catches)  # Just reset the existing cat
        self.rat.reset(self.bush_positions)

    def grid_to_pixel(self, grid_pos):
        return (grid_pos[0] * GRID_SIZE + GRID_SIZE//2,
                grid_pos[1] * GRID_SIZE + GRID_SIZE//2)

    def draw_grid(self):
        # Draw a more transparent grid
        grid_color = list(COLORS['GRID'])
        grid_color.append(40)  # Add alpha value (0-255), 40 is very transparent
        grid_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        
        # Draw vertical lines
        for x in range(0, self.width, GRID_SIZE):
            pygame.draw.line(grid_surface, grid_color, 
                           (x, 0), (x, self.height))
        
        # Draw horizontal lines
        for y in range(0, self.height, GRID_SIZE):
            pygame.draw.line(grid_surface, grid_color, 
                           (0, y), (self.width, y))
        
        self.screen.blit(grid_surface, (0, 0))

    def draw(self):
        self.screen.fill(COLORS['WHITE'])
        self.draw_grid()
        
        # Draw bushes
        for bush, pos in self.bush_positions.items():
            pixel_pos = self.grid_to_pixel(pos)
            pygame.draw.circle(self.screen, COLORS[f'BUSH{bush.value}'], 
                             pixel_pos, BUSH_SIZE)
        
        # Draw entities (cat's vision field will be drawn first)
        self.cat.draw(self.screen, self.grid_to_pixel)
        self.rat.draw(self.screen, self.grid_to_pixel)
        self.text_display.draw(self.bush_catches, self.cat, self.rat)

    def update(self):
        # Move cat
        self.cat.move(self.bush_positions, self.rat.grid_pos)
        self.rat.move()
        
        # Check if cat caught rat
        if self.cat.has_caught(self.rat):
            for bush, pos in self.bush_positions.items():
                if self.rat.is_near_bush(pos):
                    # Update catches
                    self.bush_catches[bush] += 1
                    
                    # Update cat's learning and preferences
                    self.cat.bush_associations[bush] += LEARNING_RATE
                    
                    # Update cat's preferred bush to the one with highest catches
                    self.cat.preferred_bush = max(self.bush_catches.items(), key=lambda x: x[1])[0]
                    
                    # Sort bushes by catch count for preferences
                    self.cat.bush_preferences = sorted(
                        list(Bush),
                        key=lambda b: self.bush_catches[b],
                        reverse=True
                    )
                    self.cat.current_target_index = 0  # Reset to target highest catch bush
                    
                    # Show message and reset
                    self.text_display.show_capture_message(bush)
                    time.sleep(1)
                    self.reset_simulation()
                    break

    def run(self):
        running = True
        clock = pygame.time.Clock()
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:  # Reset with 'R' key
                        self.reset_simulation()
            
            self.update()
            self.draw()
            pygame.display.flip()
            clock.tick(10)  # Slower speed for visibility
            
        pygame.quit()

if __name__ == "__main__":
    world = World()
    world.run()