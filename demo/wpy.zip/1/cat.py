import pygame
import random
from pygame import Surface, SRCALPHA
from constants import (
    COLORS, 
    ENTITY_SIZE, 
    Bush, 
    SCOUT_STEPS, 
    ROAM_STEPS,
    BUSH_ROW,
    VISION_RANGE,
    GRID_SIZE,
    GRID_HEIGHT,
    VISION_COLOR_NORMAL,
    VISION_COLOR_HUNTING
)
from movement import step_towards, roam_step

class Cat:
    def __init__(self, x, y):
        self.grid_pos = [x, y]
        self.COLOR = COLORS['CAT']
        
        # Movement and targeting
        self.current_phase = 'roam'
        self.steps_in_phase = 0
        self.scout_count = 0
        
        # First simulation: random initial target
        self.preferred_bush = random.choice(list(Bush))
        self.bush_preferences = list(Bush)
        self.current_target_index = self.bush_preferences.index(self.preferred_bush)
        self.first_bush_found = False
        
        # Learning system
        self.bush_associations = {bush: 0 for bush in Bush}
        self.bush_associations[self.preferred_bush] = 1  # Initial bias for random bush
        
        # Vision and hunting
        self.is_hunting = False
        self.vision_surface = Surface((VISION_RANGE * GRID_SIZE, VISION_RANGE * GRID_SIZE), SRCALPHA)
    
    def reset(self, bush_catches):
        # Reset position and state
        self.grid_pos = [self.grid_pos[0], GRID_HEIGHT - 20]
        
        # Reset movement states
        self.current_phase = 'headbush'
        self.steps_in_phase = 0
        self.scout_count = 0
        self.first_bush_found = False
        self.is_hunting = False
        
        # Update preferences based on catches
        if not any(bush_catches.values()):
            # First simulation: use random bush
            self.preferred_bush = random.choice(list(Bush))
            self.bush_preferences = list(Bush)
            self.current_target_index = self.bush_preferences.index(self.preferred_bush)
        else:
            # Find bushes with highest catches
            tied_bushes = self.get_tied_bushes(bush_catches)
            if tied_bushes:
                # Randomly choose one of the tied bushes as initial target
                self.preferred_bush = random.choice(tied_bushes)
                # Put tied bushes first, then rest sorted by catches
                self.bush_preferences = (
                    tied_bushes + 
                    sorted([b for b in Bush if b not in tied_bushes],
                          key=lambda b: bush_catches[b],
                          reverse=True)
                )
            else:
                # No ties, just use highest catch
                self.preferred_bush = max(bush_catches.items(), key=lambda x: x[1])[0]
                self.bush_preferences = sorted(
                    list(Bush),
                    key=lambda b: bush_catches[b],
                    reverse=True
                )
            self.current_target_index = 0
    
    def get_tied_bushes(self, bush_catches):
        if not any(bush_catches.values()):
            return []
        max_catches = max(bush_catches.values())
        return [bush for bush, catches in bush_catches.items() 
                if catches == max_catches]
    
    def get_current_phase(self):
        if self.is_hunting:
            return "Hunting!"
        elif not self.first_bush_found:
            return f"{'Roam' if self.current_phase == 'roam' else 'Initial Hunt'} ({self.steps_in_phase}/{ROAM_STEPS if self.current_phase == 'roam' else SCOUT_STEPS})"
        else:
            return f"{'Roam' if self.current_phase == 'roam' else f'Scout {self.scout_count}/6'} ({self.steps_in_phase}/{ROAM_STEPS if self.current_phase == 'roam' else SCOUT_STEPS})"
    
    def get_current_target(self):
        return self.bush_preferences[self.current_target_index]
    
    def check_rat_in_vision(self, rat_pos):
        vision_left = self.grid_pos[0] - VISION_RANGE // 2
        vision_right = self.grid_pos[0] + VISION_RANGE // 2
        vision_top = self.grid_pos[1] - VISION_RANGE // 2
        vision_bottom = self.grid_pos[1] + VISION_RANGE // 2
        
        return (vision_left <= rat_pos[0] <= vision_right and 
                vision_top <= rat_pos[1] <= vision_bottom)
    
    def check_bush_hit(self, bush_positions):
        # Check if we've hit any bush
        for bush, pos in bush_positions.items():
            if tuple(self.grid_pos) == pos:
                self.first_bush_found = True
                return True
        return False
    
    def move(self, bush_positions, rat_pos=None):
        # Check for rat in vision range
        if rat_pos and self.check_rat_in_vision(rat_pos):
            self.is_hunting = True
            new_pos = step_towards(self.grid_pos, rat_pos, weight=2)
            self.grid_pos = list(new_pos)
            return
        
        self.is_hunting = False
        
        if not self.first_bush_found:
            # Pre-first-bush pattern: roam-headbush-roam-headbush
            if self.current_phase == 'roam':
                if self.steps_in_phase >= ROAM_STEPS:
                    self.current_phase = 'headbush'
                    self.steps_in_phase = 0
                else:
                    pos1, pos2 = roam_step(self.grid_pos, BUSH_ROW)
                    self.grid_pos = list(pos2 if self.steps_in_phase == 1 else pos1)
                    self.steps_in_phase += 1
            else:  # headbush phase
                if self.steps_in_phase >= 2:
                    self.current_phase = 'roam'
                    self.steps_in_phase = 0
                else:
                    target_bush = self.get_current_target()
                    target_pos = bush_positions[target_bush]
                    new_pos = step_towards(self.grid_pos, target_pos, weight=2)
                    self.grid_pos = list(new_pos)
                    self.steps_in_phase += 1
            
            # Check if we've hit a bush
            self.check_bush_hit(bush_positions)
            
        else:
            # Post-first-bush pattern: roam-scout(x6)-roam-scout(x6)
            if self.current_phase == 'roam':
                if self.steps_in_phase >= ROAM_STEPS:
                    self.current_phase = 'scout'
                    self.steps_in_phase = 0
                else:
                    pos1, pos2 = roam_step(self.grid_pos, BUSH_ROW)
                    self.grid_pos = list(pos2 if self.steps_in_phase == 1 else pos1)
                    self.steps_in_phase += 1
            else:  # scout phase
                if self.steps_in_phase >= SCOUT_STEPS:
                    self.current_phase = 'roam'
                    self.steps_in_phase = 0
                    self.scout_count += 1
                    if self.scout_count >= 6:
                        self.current_target_index = (self.current_target_index + 1) % len(self.bush_preferences)
                        self.scout_count = 0
                else:
                    target_bush = self.get_current_target()
                    target_pos = bush_positions[target_bush]
                    new_pos = step_towards(self.grid_pos, target_pos, weight=2)
                    self.grid_pos = list(new_pos)
                    self.steps_in_phase += 1
    
    def draw(self, screen, grid_to_pixel):
        # Draw vision field
        vision_color = VISION_COLOR_HUNTING if self.is_hunting else VISION_COLOR_NORMAL
        self.vision_surface.fill((0, 0, 0, 0))  # Clear with transparent
        pygame.draw.rect(self.vision_surface, vision_color, 
                        (0, 0, VISION_RANGE * GRID_SIZE, VISION_RANGE * GRID_SIZE))
        
        vision_pos = (
            self.grid_pos[0] * GRID_SIZE - (VISION_RANGE * GRID_SIZE) // 2,
            self.grid_pos[1] * GRID_SIZE - (VISION_RANGE * GRID_SIZE) // 2
        )
        screen.blit(self.vision_surface, vision_pos)
        
        # Draw cat
        pixel_pos = grid_to_pixel(self.grid_pos)
        pygame.draw.circle(screen, self.COLOR, pixel_pos, ENTITY_SIZE)
    
    def has_caught(self, rat):
        return tuple(self.grid_pos) == tuple(rat.grid_pos)