from dataclasses import dataclass
from typing import List, Optional
from enum import Enum, auto
from constants import Bush

class PatternType(Enum):
    NOVEL = auto()    # Same bush immediate catches in H1
    STRESS = auto()   # Same initial guess fails in H2

@dataclass
class Pattern:
    pattern_type: PatternType
    blocked_bush: Bush
    
class EpiTracker:
    def __init__(self, cat_ref):
        self.cat = cat_ref
    
    def check_patterns(self, memory_states) -> Optional[Pattern]:
        """Check for NOVEL or STRESS patterns in recent memory states"""
        if len(memory_states) < 2:
            return None
            
        last_two = [state.details for state in memory_states[-2:]]
        if len(last_two) != 2:
            return None
            
        # Parse patterns
        pattern1 = self._parse_pattern(last_two[0])
        pattern2 = self._parse_pattern(last_two[1])
        
        if not pattern1 or not pattern2:
            return None
            
        # Check for NOVEL pattern (same bush immediate catches in H1)
        if (pattern1['hunt_type'] == 'H1' and pattern2['hunt_type'] == 'H1' and
            pattern1['ib'] == pattern1['rb'] and pattern2['ib'] == pattern2['rb'] and
            pattern1['ib'] == pattern2['ib']):
            print(f"NOVEL pattern detected: {pattern1['ib']}")
            return Pattern(
                PatternType.NOVEL,
                Bush[f"BUSH{pattern1['ib']}"]
            )
            
        # Check for STRESS pattern (same initial guess fails in H2)
        if (pattern1['hunt_type'] == 'H2' and pattern2['hunt_type'] == 'H2' and
            pattern1['ib'] == pattern2['ib'] and
            pattern1['ib'] != pattern1['rb'] and pattern2['ib'] != pattern2['rb']):
            print(f"STRESS pattern detected: {pattern1['ib']}")
            return Pattern(
                PatternType.STRESS,
                Bush[f"BUSH{pattern1['ib']}"]
            )
            
        return None
    
    def _parse_pattern(self, pattern_str: str) -> Optional[dict]:
        """Parse pattern string like 'IB2-RB3-H1-CR' or 'IB2-RB3-H1-CF' into components"""
        try:
            parts = pattern_str.split('-')
            return {
                'ib': int(parts[0][2]),  # Extract number from IB2
                'rb': int(parts[1][2]),  # Extract number from RB3
                'hunt_type': parts[2],   # H1 or H2
                'ending': parts[3]       # CR or CF
            }
        except:
            return None
    
    def update_blocks(self, memory_states) -> Optional[Pattern]:
        """Check patterns and update marker system"""
        pattern = self.check_patterns(memory_states)
        if pattern:
            # Pass both pattern type and bush to marker
            self.cat.marker.add_pattern(pattern.pattern_type.name, pattern.blocked_bush)
            print(f"Added pattern to marker: {pattern.pattern_type.name} for {pattern.blocked_bush.name}")
        return pattern