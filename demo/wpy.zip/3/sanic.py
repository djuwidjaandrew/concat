from rat_base import RatBase
from constants import COLORS

class Sanic(RatBase):
    def __init__(self, bush_positions):
        super().__init__(bush_positions)
        self.is_being_hunted = False

    def _get_color(self):
        return COLORS['SANIC']
        
    def _get_hunting_overlay_color(self):
        return (0, 191, 255, 128)  # Light blue with alpha
        
    def get_capture_message(self):
        return "CAT DIED INSTEAD (tired)!"

    def _get_speed(self):
        """Sanic moves 3x faster when hunted"""
        return 3 if self.is_being_hunted else 1

    def update_hunted_status(self, is_hunted):
        """Update whether Sanic is being hunted"""
        self.is_being_hunted = is_hunted