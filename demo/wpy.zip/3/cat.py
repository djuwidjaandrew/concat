import pygame
import random
from pygame import Surface, SRCALPHA
from constants import (
    COLORS, 
    ENTITY_SIZE, 
    Bush, 
    SCOUT_STEPS, 
    ROAM_STEPS,
    BUSH_ROW,
    VISION_RANGE,
    GRID_SIZE,
    GRID_HEIGHT,
    VISION_COLOR_NORMAL,
    VISION_COLOR_HUNTING,
    HEADBUSH_STEPS,
    INITIAL_ROAM_STEPS
)
from movement import step_towards, roam_step
from phase import PhaseManager, ParentPhase, SubPhase
from temp_memory import TempMemory
from epi import EpiTracker
from marker import Marker

class Cat:
    def __init__(self, x, y, world_ref=None):
        # Basic setup
        self.grid_pos = [x, y]
        self.COLOR = COLORS['CAT']
        self.world = world_ref  # Store reference to world
        
        # Phase and Memory Systems
        self.phase_manager = PhaseManager()
        self.temp_memory = TempMemory()
        self.marker = Marker()
        self.epi_tracker = EpiTracker(self)
        
        # Bush targeting system
        self.bush_preferences = list(Bush)
        self.preferred_bush = random.choice(self.bush_preferences)
        self.current_target = self.preferred_bush
        self.current_target_index = self.bush_preferences.index(self.preferred_bush)
        self.direction = -1
        
        # Vision and hunting
        self.is_hunting = False
        self.vision_surface = Surface((VISION_RANGE * GRID_SIZE, VISION_RANGE * GRID_SIZE), SRCALPHA)
        
        # Hunt tracking
        self.initial_target = None
        self.scout_count = 0
        self.steps_in_phase = 0
        self.roam_step_count = 0
        
        # Block display
        self.block_display = None
        self.block_message = None
        self.block_message_timer = 0
        self.current_prey = None  # Add this to track which rat is being hunted

    def reset(self, bush_catches):
        """Reset cat state"""
        self.grid_pos = [self.grid_pos[0], GRID_HEIGHT - 40]
        self.phase_manager.reset()
        self.scout_count = 0
        self.initial_target = None
        self.steps_in_phase = 0
        self.roam_step_count = 0
        self.block_message = None
        self.block_message_timer = 0
        print(f"Reset called, phase: {self.phase_manager.parent_phase}")
        self.update_preferences(bush_catches)

    def update_preferences(self, bush_catches):
        if not any(bush_catches.values()):
            return
        max_catches = max(bush_catches.values())
        best_bushes = [bush for bush, catches in bush_catches.items() 
                      if catches == max_catches]
        if best_bushes:
            self.preferred_bush = random.choice(best_bushes)
            self.current_target = self.preferred_bush

    def choose_unblocked_bush(self):
        """Choose a bush that isn't blocked for initial phase"""
        # Check both NOVEL and STRESS markers
        available_bushes = [bush for bush in self.bush_preferences 
                          if not (self.marker.get_blocked_bush("NOVEL") == bush or 
                                 self.marker.get_blocked_bush("STRESS") == bush)]
        
        if not available_bushes:  # If all are blocked, use any bush
            available_bushes = self.bush_preferences
            
        new_target = random.choice(available_bushes)
        print(f"Choosing new unblocked bush: {new_target.name}")
        return new_target

    def move(self, bush_positions, rat_pos, simulation_count):
        # Update block message timer
        if self.block_message_timer > 0:
            self.block_message_timer -= 1
            if self.block_message_timer == 0:
                self.block_message = None

        # Reset hunting state
        self.is_hunting = False
        self.current_prey = None

        # Check for rats in vision range
        if rat_pos and self.check_rat_in_vision(rat_pos):
            self.is_hunting = True
            self.current_prey = 'rat'
            new_pos = step_towards(self.grid_pos, rat_pos, weight=2)
            self.grid_pos = list(new_pos)
            return

        # Check for Sanic if it exists
        if self.world and self.world.sanic and self.check_rat_in_vision(self.world.sanic.grid_pos):
            self.is_hunting = True
            self.current_prey = 'sanic'
            new_pos = step_towards(self.grid_pos, self.world.sanic.grid_pos, weight=2)
            self.grid_pos = list(new_pos)
            return

        current_phase = self.phase_manager.get_current_phase()
        parent_phase = self.phase_manager.get_parent_phase()
        target_pos = bush_positions[self.current_target]

        # Handle phases
        if parent_phase in [ParentPhase.P_INITIAL_A, ParentPhase.P_INITIAL_B]:
            if not self.initial_target:
                self.initial_target = self.current_target
                print(f"Starting initial hunt at {self.initial_target.name}")
                
            if current_phase == SubPhase.ROAM:
                if self.steps_in_phase >= ROAM_STEPS:
                    self.phase_manager.transition_to_next()
                    self.steps_in_phase = 0
                else:
                    pos1, pos2 = roam_step(self.grid_pos, BUSH_ROW)
                    self.grid_pos = list(pos2 if self.steps_in_phase == 1 else pos1)
                    self.steps_in_phase += 1
                    
            elif current_phase == SubPhase.HEADBUSH:
                new_pos = step_towards(self.grid_pos, target_pos)
                self.grid_pos = list(new_pos)
                self.steps_in_phase += 1
                
                # Check if reached bush in INITIAL_B
                if parent_phase == ParentPhase.P_INITIAL_B:
                    if tuple(self.grid_pos) == tuple(target_pos):
                        self.phase_manager.mark_bush_reached()
                
                if self.steps_in_phase >= HEADBUSH_STEPS:
                    self.phase_manager.transition_to_next()
                    self.steps_in_phase = 0
                    
            elif current_phase == SubPhase.PONDER:
                # Check for patterns first
                pattern = self.epi_tracker.update_blocks(self.temp_memory.get_last_states())
            
                if pattern:
                    print(f"Pattern detected during PONDER: {pattern.pattern_type.name}")
                    # Add pattern to marker system
                    self.marker.add_pattern(pattern.pattern_type.name, pattern.blocked_bush)
            
                # Check if current target should be blocked
                should_block, marker_type = self.marker.check_and_block(self.current_target)
                if should_block:
                    if self.block_display:
                        # marker_type is now the Enum value, so we can use .name
                        self.block_display.set_block(self.current_target, marker_type.name)
                    self.current_target = self.choose_unblocked_bush()
                    print(f"Block applied, new target: {self.current_target.name}")
                else:
                    # If no block applied, decay markers
                    self.marker.decay_markers()
            
                # Record final choice
                self.temp_memory.record_initial_choice(
                    simulation_count,
                    self.current_target.value
                )
                self.phase_manager.transition_to_next()
                
        else:  # P_SCOUT phase
            if current_phase == SubPhase.ROAM:
                # Do the one-step-one-step roaming
                if self.roam_step_count < 2:  # Two steps per roam phase
                    pos1, pos2 = roam_step(self.grid_pos, BUSH_ROW)
                    self.grid_pos = list(pos2 if self.roam_step_count == 0 else pos1)
                    self.roam_step_count += 1
                else:
                    self.phase_manager.transition_to_next()
                    self.roam_step_count = 0
                    
            elif current_phase == SubPhase.SCOUT:
                # Scout/ratchet behavior
                if tuple(self.grid_pos) == tuple(target_pos):
                    self.scout_count += 1
                    if self.scout_count >= 3:
                        print(f"Ratcheting from {self.current_target.name}")
                        self.current_target = self.get_next_target()
                        print(f"to {self.current_target.name}")
                        self.scout_count = 0
                
                new_pos = step_towards(self.grid_pos, target_pos)
                self.grid_pos = list(new_pos)
                self.steps_in_phase += 1
                
                if self.steps_in_phase >= SCOUT_STEPS:
                    self.phase_manager.transition_to_next()
                    self.steps_in_phase = 0

    def get_next_target(self):
        current_index = self.bush_preferences.index(self.current_target)
        if self.direction == -1 and current_index == 0:
            self.direction = 1
        elif self.direction == 1 and current_index == len(self.bush_preferences) - 1:
            self.direction = -1
        next_index = current_index + self.direction
        return self.bush_preferences[next_index]

    def draw(self, screen, grid_to_pixel):
        # Draw vision field with appropriate color
        if self.is_hunting:
            vision_color = (0, 191, 255, 80) if self.current_prey == 'sanic' else VISION_COLOR_HUNTING
        else:
            vision_color = VISION_COLOR_NORMAL
            
        self.vision_surface.fill((0,0,0,0))
        pygame.draw.rect(self.vision_surface, vision_color, 
                        (0, 0, VISION_RANGE * GRID_SIZE, VISION_RANGE * GRID_SIZE))
        
        # Center vision field on cat
        pixel_pos = grid_to_pixel(self.grid_pos)
        vision_pos = (pixel_pos[0] - VISION_RANGE * GRID_SIZE // 2,
                     pixel_pos[1] - VISION_RANGE * GRID_SIZE // 2)
        screen.blit(self.vision_surface, vision_pos)
        
        # Draw cat
        pygame.draw.circle(screen, self.COLOR, pixel_pos, ENTITY_SIZE)

    def check_rat_in_vision(self, rat_pos):
        """Check if rat position is within vision range"""
        if not rat_pos:
            return False
        dx = abs(self.grid_pos[0] - rat_pos[0])
        dy = abs(self.grid_pos[1] - rat_pos[1])
        return dx <= VISION_RANGE//2 and dy <= VISION_RANGE//2

    def has_caught(self, rat):
        return tuple(self.grid_pos) == tuple(rat.grid_pos)

    def get_current_phase(self):
        return self.phase_manager.get_current_phase()

    def get_current_target(self):
        return self.current_target

    def get_block_message(self):
        """Return current block message for display"""
        return self.block_message

    def set_block_display(self, block_display):
        """Set reference to block display"""
        self.block_display = block_display