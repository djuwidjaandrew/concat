from rat_base import RatBase
from constants import COLORS

class Rat(RatBase):
    def _get_color(self):
        return COLORS['RAT']
        
    def _get_hunting_overlay_color(self):
        return (255, 0, 0, 128)  # Red with alpha
        
    def get_capture_message(self):
        return "Rat caught!"