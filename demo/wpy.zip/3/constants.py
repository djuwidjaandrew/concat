from enum import Enum

class Bush(Enum):
    BUSH1 = 1
    BUSH2 = 2
    BUSH3 = 3
    BUSH4 = 4
    BUSH5 = 5

# Window settings
WINDOW_WIDTH = 640
WINDOW_HEIGHT = 576
GRID_SIZE = 4
GRID_WIDTH = WINDOW_WIDTH // GRID_SIZE
GRID_HEIGHT = WINDOW_HEIGHT // GRID_SIZE

# Game settings
BUSH_ROW = 10
SCOUT_STEPS = 3
ROAM_STEPS = 4
HEADBUSH_STEPS = 24
INITIAL_ROAM_STEPS = 4
SIMULATION_RESET_COUNT = 10

# Vision and hunting settings
VISION_RANGE = 6
VISION_COLOR_NORMAL = (128, 128, 128, 128)  # Gray with alpha
VISION_COLOR_HUNTING = (255, 0, 0, 128)     # Red with alpha

# Colors
COLORS = {
    'WHITE': (255, 255, 255),
    'BLACK': (0, 0, 0),
    'RED': (255, 0, 0),
    'LEFT_BG': (245, 235, 230),   
    'RIGHT_BG': (230, 225, 220),  
    'BUSH1': (50, 205, 50),      
    'BUSH2': (0, 0, 255),        
    'BUSH3': (255, 255, 0),      
    'BUSH4': (255, 165, 0),      
    'BUSH5': (128, 0, 128),      
    'CAT': (50, 205, 50),        
    'RAT': (255, 0, 0),          
    'GRID': (220, 220, 220),
    'TEXT': (100, 100, 100),
    'SANIC': (0, 191, 255),  # Light blue
}

# Visual settings
DIVIDER_WIDTH = 2
BUSH_SIZE = 6
ENTITY_SIZE = 4

# Learning settings
LEARNING_RATE = 0.1

# Rat preferences
RAT_PREFERENCES = [0.30, 0.15, 0.15, 0.15, 0.15]