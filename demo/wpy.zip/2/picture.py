import pygame
from constants import COLORS, Bush

class BlockDisplay:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.Font(None, 24)
        self.block_info = None
        
    def set_block(self, bush: Bush, pattern_type: str):
        """Set block information to display"""
        self.block_info = {
            'bush': bush,
            'pattern_type': pattern_type
        }
        
    def clear_block(self):
        """Clear block display"""
        self.block_info = None
        
    def draw(self):
        if not self.block_info:
            return
            
        # Draw in top-right corner
        x_start = self.screen.get_width() - 200
        y_start = 50
        
        # Draw bush circle
        bush_color = COLORS[f'BUSH{self.block_info["bush"].value}']
        pygame.draw.circle(self.screen, bush_color, (x_start + 20, y_start + 20), 15)
        
        # Draw color name
        color_text = self.font.render(f"COLOR {self.block_info['bush'].value}", True, COLORS['TEXT'])
        self.screen.blit(color_text, (x_start + 50, y_start + 10))
        
        # Draw block reason
        block_text = self.font.render(
            f"blocked by {self.block_info['pattern_type']}", 
            True, 
            COLORS['RED']
        )
        self.screen.blit(block_text, (x_start + 20, y_start + 40))