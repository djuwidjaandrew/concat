from enum import Enum
from dataclasses import dataclass
from typing import Optional
from constants import Bush

class MarkerType(Enum):
    NOVEL = "Novel^^"
    STRESS = "Stress^^"

@dataclass
class MarkerState:
    marker_type: MarkerType
    bush: Bush
    count: int = 2  # Start with 2 blocks available
    
class Marker:
    def __init__(self):
        self.active_markers = {}  # bush_name -> MarkerState
        
    def add_pattern(self, pattern_type: str, bush: Bush):
        """Add a new pattern detection for a specific bush"""
        marker_type = MarkerType[pattern_type]
        bush_key = bush.name
        
        if bush_key not in self.active_markers:
            self.active_markers[bush_key] = MarkerState(marker_type, bush)
            print(f"Added new marker: {marker_type.value} for {bush.name}")
    
    def check_and_block(self, initial_bush: Bush) -> tuple[bool, Optional[str]]:
        """Check if initial bush should be blocked and use a block if available"""
        bush_key = initial_bush.name
        if bush_key in self.active_markers:
            marker = self.active_markers[bush_key]
            if marker.count > 0:
                marker.count -= 1
                print(f"Used block for {marker.marker_type.value} on {bush_key}, {marker.count} remaining")
                if marker.count == 0:
                    del self.active_markers[bush_key]
                return True, marker.marker_type
        return False, None
    
    def decay_markers(self):
        """Decay all markers by 1 count at end of PONDER if no block was used"""
        bushes_to_remove = []
        for bush_key, marker in self.active_markers.items():
            marker.count -= 1
            print(f"Decaying {marker.marker_type.value} for {bush_key}, {marker.count} remaining")
            if marker.count <= 0:
                bushes_to_remove.append(bush_key)
                
        for bush_key in bushes_to_remove:
            del self.active_markers[bush_key]
    
    def get_blocked_bush(self, pattern_type: str) -> Optional[Bush]:
        """Get bush that's blocked by this pattern type, if any"""
        for marker in self.active_markers.values():
            if marker.marker_type.name == pattern_type and marker.count > 0:
                return marker.bush
        return None
    
    def get_active_markers(self) -> list[tuple[str, int, str]]:
        """Get list of active markers for display"""
        return [(m.marker_type.value, m.count, m.bush.name) 
                for m in self.active_markers.values()]