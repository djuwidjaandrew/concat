class StressTracker:
    def __init__(self):
        self.consecutive_misses = {}  # Track consecutive wrong first guesses
        self.block_count = {}         # Track remaining blocks per bush
        self.last_miss_simulation = {}  # Track which simulation had last miss
        
    def check_miss(self, bush, simulation_count):
        """Track misses and set blocks if needed"""
        if bush not in self.consecutive_misses:
            self.consecutive_misses[bush] = 0
            self.last_miss_simulation[bush] = simulation_count - 1
        
        # Check if this is consecutive with last miss
        if simulation_count != self.last_miss_simulation[bush] + 1:
            print(f"Stress Tracker: Reset counter for {bush.name} (non-consecutive: last={self.last_miss_simulation[bush]}, current={simulation_count})")
            self.consecutive_misses[bush] = 0
        
        self.consecutive_misses[bush] += 1
        self.last_miss_simulation[bush] = simulation_count
        print(f"Stress Tracker: Miss at {bush.name} (#{self.consecutive_misses[bush]}) in sim {simulation_count}")
        
        if self.consecutive_misses[bush] >= 2:
            print(f"Stress Tracker: Setting TWO headbush blocks on {bush.name}")
            self.block_count[bush] = 2
            self.consecutive_misses[bush] = 0
    
    def is_blocked(self, bush):
        """Check if bush is currently blocked for headbush"""
        return bush in self.block_count and self.block_count[bush] > 0
    
    def use_block(self, bush):
        """Use up one block and return status message"""
        if bush in self.block_count and self.block_count[bush] > 0:
            self.block_count[bush] -= 1
            blocks_left = self.block_count[bush]
            if blocks_left == 0:
                del self.block_count[bush]
            return f"Stress blocks {bush.name} {'TWICE' if blocks_left == 1 else 'ONCE'}"
        return None