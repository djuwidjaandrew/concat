import pygame
from constants import Bush, COLORS

class TextDisplay:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.Font(None, 16)
        self.BLACK = COLORS['BLACK']
        self.RED = COLORS['RED']
        
    def draw(self, bush_catches, cat, rat):
        texts = [
            f"Phase: {cat.get_current_phase()} ({cat.phase_manager.get_parent_phase().name})",
            f"Simulation: {rat.simulation_count}",
            f"Bush Catches: B1:{bush_catches[Bush.BUSH1]} B2:{bush_catches[Bush.BUSH2]} B3:{bush_catches[Bush.BUSH3]} B4:{bush_catches[Bush.BUSH4]} B5:{bush_catches[Bush.BUSH5]}",
            f"Current Target: {cat.get_current_target().name}",
            f"Rat's preferred bush: {rat.preferred_bush.name}",
            "",
            "Memory Log (Last 2):"
        ]
        
        # Add last two memory states
        last_states = cat.temp_memory.get_last_states(2)
        for state in last_states:
            texts.append(f"Run #{state.run_number}: {state}")
            
        # Add marker display with spacing
        texts.extend(["", "", "Active Markers:"])
        for marker_text, count, bush_name in cat.marker.get_active_markers():
            texts.append(f"{marker_text} ({count}x) → {bush_name}")
        
        # Draw all texts
        for i, text in enumerate(texts):
            text_surface = self.font.render(text, True, COLORS['TEXT'])
            self.screen.blit(text_surface, (5, 5 + i * 15))
    
    def show_capture_message(self, bush):
        text = f"Rat caught at {bush.name}!"
        text_surface = self.font.render(text, True, self.RED)
        self.screen.blit(text_surface, 
                        (self.screen.get_width()//2 - 30, 
                         self.screen.get_height()//2))
        pygame.display.flip()
    
    def show_sleep_message(self):
        text = "Sleep. Evaluating patterns..."
        text_surface = self.font.render(text, True, self.BLACK)
        self.screen.blit(text_surface, 
                        (self.screen.get_width()//2 - 50, 
                         self.screen.get_height()//2))
        pygame.display.flip()