from enum import Enum, auto

class ParentPhase(Enum):
    P_INITIAL_A = auto()  # First approach with PONDER
    P_INITIAL_B = auto()  # Second approach without PONDER
    P_SCOUT = auto()      # Regular hunting/ratcheting phase

class SubPhase(Enum):
    ROAM = auto()
    HEADBUSH = auto()
    PONDER = auto()
    SCOUT = auto()  # Added for clarity in scout phase

class PhaseManager:
    def __init__(self):
        self.parent_phase = ParentPhase.P_INITIAL_A
        self.current_subphase = SubPhase.ROAM
        self.steps_in_phase = 0
        self.sequence_step = 0
        self.reached_first_bush = False
        self.first_bush_visited = False
    
    def get_current_phase(self):
        return self.current_subphase
    
    def get_parent_phase(self):
        return self.parent_phase
    
    def mark_bush_reached(self):
        """Called when cat reaches a bush in INITIAL_B"""
        if self.parent_phase == ParentPhase.P_INITIAL_B and not self.first_bush_visited:
            self.first_bush_visited = True
            print("First bush reached in INITIAL_B")
    
    def transition_to_next(self):
        """Transition to next phase based on current state"""
        self.steps_in_phase = 0
        
        if self.parent_phase == ParentPhase.P_INITIAL_A:
            # ROAM -> HEADBUSH -> ROAM -> HEADBUSH -> PONDER -> ROAM(B)
            if self.current_subphase == SubPhase.ROAM:
                self.current_subphase = SubPhase.HEADBUSH
            elif self.current_subphase == SubPhase.HEADBUSH:
                if self.sequence_step == 0:
                    self.current_subphase = SubPhase.ROAM
                    self.sequence_step = 1
                else:
                    self.current_subphase = SubPhase.PONDER
            elif self.current_subphase == SubPhase.PONDER:
                self.current_subphase = SubPhase.ROAM
                self.parent_phase = ParentPhase.P_INITIAL_B
                self.sequence_step = 0
                print("Completed Initial A, moving to Initial B")
                
        elif self.parent_phase == ParentPhase.P_INITIAL_B:
            # ROAM -> HEADBUSH -> ROAM -> HEADBUSH
            if self.current_subphase == SubPhase.ROAM:
                self.current_subphase = SubPhase.HEADBUSH
            elif self.current_subphase == SubPhase.HEADBUSH:
                self.current_subphase = SubPhase.ROAM
                if self.first_bush_visited:
                    self.sequence_step += 1
                    if self.sequence_step >= 2:
                        self.parent_phase = ParentPhase.P_SCOUT
                        self.current_subphase = SubPhase.ROAM
                        print("Completed Initial B, moving to Scout phase")
                    
        elif self.parent_phase == ParentPhase.P_SCOUT:
            # Alternate between ROAM and SCOUT
            if self.current_subphase == SubPhase.ROAM:
                self.current_subphase = SubPhase.SCOUT
            else:
                self.current_subphase = SubPhase.ROAM
        
        print(f"Transitioned to {self.current_subphase} in {self.parent_phase}")
        return self.current_subphase
    
    def reset(self):
        """Reset to initial state"""
        self.parent_phase = ParentPhase.P_INITIAL_A
        self.current_subphase = SubPhase.ROAM
        self.steps_in_phase = 0
        self.sequence_step = 0
        self.reached_first_bush = False
        self.first_bush_visited = False