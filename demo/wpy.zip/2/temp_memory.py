from dataclasses import dataclass
from typing import List
import sqlite3
import time

@dataclass
class MemoryState:
    run_number: int
    state_type: str
    details: str
    timestamp: float = time.time()

    def __str__(self):
        return f"{self.state_type}: {self.details}"

class TempMemory:
    def __init__(self):
        self.states: List[MemoryState] = []
        self.db_path = f"cat_logs/cat_memory_{time.strftime('%Y%m%d_%H%M%S')}.db"
        self.init_database()
        self._temp_state = None  # For building complete patterns
        print(f"Database initialized at: {self.db_path}")

    def init_database(self):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS memory_states
                    (run_number INTEGER, state_type TEXT, details TEXT, timestamp REAL)''')
        conn.commit()
        conn.close()

    def record_initial_choice(self, run_number: int, bush_value: int):
        """Start building a pattern with initial bush choice"""
        self._temp_state = f"IB{bush_value}"  # Store temporarily, don't save yet

    def update_initial_with_rat_bush(self, run_number: int, rat_bush_value: int):
        """Complete the pattern for initial phase catches"""
        if self._temp_state:
            complete_pattern = f"{self._temp_state}-RB{rat_bush_value}-H1-CR"
            state = MemoryState(run_number, "H1", complete_pattern)
            self.states.append(state)
            self.save_to_db(state)
            self._temp_state = None

    def record_hunt_choice(self, run_number: int, initial_bush: int, rat_bush: int):
        """Record complete hunt pattern"""
        complete_pattern = f"IB{initial_bush}-RB{rat_bush}-H2-CR"
        state = MemoryState(run_number, "H2", complete_pattern)
        self.states.append(state)
        self.save_to_db(state)

    def save_to_db(self, state: MemoryState):
        conn = sqlite3.connect(self.db_path)
        c = conn.cursor()
        c.execute("INSERT INTO memory_states VALUES (?, ?, ?, ?)",
                 (state.run_number, state.state_type, state.details, state.timestamp))
        conn.commit()
        conn.close()

    def get_last_states(self, n: int = 2) -> List[MemoryState]:
        """Only return complete patterns"""
        return [s for s in self.states[-n:] if "-CR" in s.details]