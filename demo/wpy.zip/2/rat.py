import pygame
import random
from constants import (
    COLORS, 
    ENTITY_SIZE, 
    GRID_WIDTH, 
    GRID_HEIGHT, 
    Bush,
    RAT_PREFERENCES,
    SIMULATION_RESET_COUNT
)

class Rat:
    def __init__(self, bush_positions):
        self.bush_positions = bush_positions
        self.COLOR = COLORS['RAT']
        self.grid_pos = None
        
        # Preference system
        self.simulation_count = 0
        self.preferred_bush = random.choice(list(Bush))
        self.bush_weights = {
            bush: weight for bush, weight in zip(Bush, RAT_PREFERENCES)
        }
        
        # Initial position
        self.reset(bush_positions)
    
    def reset(self, bush_positions):
        self.simulation_count += 1
        if self.simulation_count % SIMULATION_RESET_COUNT == 0:
            self.preferred_bush = random.choices(
                list(Bush), 
                weights=[self.bush_weights[b] for b in Bush]
            )[0]
        
        # Choose bush position
        if random.random() < 0.5:  # 50% chance for preferred bush
            chosen_bush = self.preferred_bush
        else:
            other_bushes = [b for b in Bush if b != self.preferred_bush]
            chosen_bush = random.choice(other_bushes)
        
        bush_pos = bush_positions[chosen_bush]
        self.home_bush_pos = bush_pos
        
        # Random start position near bush
        dx = random.randint(-1, 1)
        dy = random.randint(-1, 1)
        self.grid_pos = [
            max(0, min(GRID_WIDTH - 1, bush_pos[0] + dx)),
            max(0, min(GRID_HEIGHT - 1, bush_pos[1] + dy))
        ]
    
    def move(self):
        if not self.grid_pos:
            return
        
        dx = random.choice([-1, 0, 1])
        dy = random.choice([-1, 0, 1])
        
        new_x = max(0, min(GRID_WIDTH - 1, self.grid_pos[0] + dx))
        new_y = max(0, min(GRID_HEIGHT - 1, self.grid_pos[1] + dy))
        
        if (abs(new_x - self.home_bush_pos[0]) <= 4 and
            abs(new_y - self.home_bush_pos[1]) <= 4):
            self.grid_pos = [new_x, new_y]
    
    def draw(self, screen, grid_to_pixel):
        if self.grid_pos:
            pixel_pos = grid_to_pixel(self.grid_pos)
            pygame.draw.circle(screen, self.COLOR, pixel_pos, ENTITY_SIZE)
    
    def is_near_bush(self, bush_pos):
        if not self.grid_pos:
            return False
        return (abs(self.grid_pos[0] - bush_pos[0]) <= 2 and
                abs(self.grid_pos[1] - bush_pos[1]) <= 2)