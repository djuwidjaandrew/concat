import pygame
import random
import time
import math
import os
from cat import Cat
from rat import Rat
from text_display import TextDisplay
from constants import (
    Bush, 
    COLORS, 
    GRID_SIZE, 
    WINDOW_WIDTH, 
    WINDOW_HEIGHT, 
    BUSH_SIZE,
    GRID_HEIGHT,
    LEARNING_RATE
)
from phase import ParentPhase
from picture import BlockDisplay

class World:
    def __init__(self):
        pygame.init()
        self.width = WINDOW_WIDTH
        self.height = WINDOW_HEIGHT
        self.screen = pygame.display.set_mode((self.width, self.height))
        pygame.display.set_caption("Cat and Rat Simulation")
        
        # Create logs directory if it doesn't exist
        if not os.path.exists('cat_logs'):
            os.makedirs('cat_logs')
        
        # Setup bush positions
        center_x = WINDOW_WIDTH // 2
        bush_y = int(WINDOW_HEIGHT * 0.2)
        bush_spacing = 90
        total_width = bush_spacing * 4
        start_x = center_x - total_width // 2
        
        self.bush_positions = {}
        for i, bush in enumerate(Bush):
            x = start_x + (i * bush_spacing)
            arc_offset = -20 * math.sin(math.pi * i / 4)
            y = bush_y + arc_offset
            self.bush_positions[bush] = (int(x/GRID_SIZE), int(y/GRID_SIZE))
        
        self.bush_catches = {bush: 0 for bush in Bush}
        
        # Initialize entities
        self.cat = Cat(center_x/GRID_SIZE, GRID_HEIGHT - 40)
        self.rat = Rat(self.bush_positions)
        self.text_display = TextDisplay(self.screen)
        self.block_display = BlockDisplay(self.screen)
        self.cat.set_block_display(self.block_display)

    def reset_simulation(self):
        self.cat.reset(self.bush_catches)
        self.rat.reset(self.bush_positions)
        self.block_display.clear_block()

    def grid_to_pixel(self, grid_pos):
        return (grid_pos[0] * GRID_SIZE + GRID_SIZE//2,
                grid_pos[1] * GRID_SIZE + GRID_SIZE//2)

    def draw_grid(self):
        grid_color = list(COLORS['GRID'])
        grid_color.append(40)
        grid_surface = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        
        for x in range(0, self.width, GRID_SIZE):
            pygame.draw.line(grid_surface, grid_color, 
                           (x, 0), (x, self.height))
        
        for y in range(0, self.height, GRID_SIZE):
            pygame.draw.line(grid_surface, grid_color, 
                           (0, y), (self.width, y))
        
        self.screen.blit(grid_surface, (0, 0))

    def draw(self):
        self.screen.fill(COLORS['WHITE'])
        self.draw_grid()
        
        # Draw bushes and entities
        for bush, pos in self.bush_positions.items():
            pixel_pos = self.grid_to_pixel(pos)
            pygame.draw.circle(self.screen, COLORS[f'BUSH{bush.value}'], 
                             pixel_pos, BUSH_SIZE)
        
        self.cat.draw(self.screen, self.grid_to_pixel)
        self.rat.draw(self.screen, self.grid_to_pixel)
        self.text_display.draw(self.bush_catches, self.cat, self.rat)
        self.block_display.draw()

    def update(self):
        # Store initial positions for catch analysis
        start_pos = tuple(self.cat.grid_pos)
        
        # Move entities
        self.cat.move(self.bush_positions, self.rat.grid_pos, self.rat.simulation_count)
        self.rat.move()
        
        # Check if cat caught rat
        if self.cat.has_caught(self.rat):
            for bush, pos in self.bush_positions.items():
                if self.rat.is_near_bush(pos):
                    self.bush_catches[bush] += 1
                    
                    # Record catch with proper memory format
                    parent_phase = self.cat.phase_manager.get_parent_phase()
                    
                    if parent_phase in [ParentPhase.P_INITIAL_A, ParentPhase.P_INITIAL_B]:
                        # Update initial choice with rat's bush (IBx-RBy)
                        self.cat.temp_memory.update_initial_with_rat_bush(
                            self.rat.simulation_count,
                            bush.value
                        )
                    else:  # Scout phase
                        # Record full hunt pattern (IBx-RBy-H2-CR)
                        self.cat.temp_memory.record_hunt_choice(
                            self.rat.simulation_count,
                            self.cat.initial_target.value,
                            bush.value
                        )
                    
                    # Display catch and reset
                    self.text_display.show_capture_message(bush)
                    time.sleep(1)
                    self.reset_simulation()
                    break

    def run(self):
        running = True
        clock = pygame.time.Clock()
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r:
                        self.reset_simulation()
            
            self.update()
            self.draw()
            pygame.display.flip()
            clock.tick(10)
            
        pygame.quit()

if __name__ == "__main__":
    world = World()
    world.run()