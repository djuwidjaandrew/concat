class NovelTracker:
    def __init__(self):
        self.consecutive_catches = {}  # Track consecutive catches per bush
        self.block_count = {}         # Track remaining blocks per bush
        self.last_catch_simulation = {}  # Track which simulation had last catch
        
    def check_catch(self, bush, is_immediate, simulation_count):
        """Track catches and set blocks if needed"""
        if bush not in self.consecutive_catches:
            self.consecutive_catches[bush] = 0
            self.last_catch_simulation[bush] = simulation_count - 1
        
        if is_immediate:
            # Check if this is consecutive with last catch
            if simulation_count != self.last_catch_simulation[bush] + 1:
                print(f"Novel Tracker: Reset counter for {bush.name} (non-consecutive: last={self.last_catch_simulation[bush]}, current={simulation_count})")
                self.consecutive_catches[bush] = 0
            
            self.consecutive_catches[bush] += 1
            self.last_catch_simulation[bush] = simulation_count
            print(f"Novel Tracker: Immediate catch at {bush.name} (#{self.consecutive_catches[bush]}) in sim {simulation_count}")
            
            if self.consecutive_catches[bush] >= 2:
                print(f"Novel Tracker: Setting TWO blocks on {bush.name}")
                self.block_count[bush] = 2
                self.consecutive_catches[bush] = 0
        else:
            print(f"Novel Tracker: Non-immediate catch at {bush.name}, resetting counter")
            self.consecutive_catches[bush] = 0
    
    def is_blocked(self, bush):
        """Check if bush is currently blocked"""
        return bush in self.block_count and self.block_count[bush] > 0
    
    def use_block(self, bush):
        """Use up one block and return status message"""
        if bush in self.block_count and self.block_count[bush] > 0:
            self.block_count[bush] -= 1
            blocks_left = self.block_count[bush]
            if blocks_left == 0:
                del self.block_count[bush]
            return f"Novel blocks {bush.name} {'TWICE' if blocks_left == 1 else 'ONCE'}"
        return None